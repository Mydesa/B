# frozen_string_literal: true

module WPScan
  module Model
    # Config Backup
    class ConfigBackup < InterestingFinding
    end
  end
end
