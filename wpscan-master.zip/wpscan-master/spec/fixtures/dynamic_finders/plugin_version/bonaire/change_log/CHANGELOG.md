# Change Log

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## Version 0.1.1
### Changed
- Code cleanup
- Ensured compatibility with PHPMailer

## Version 0.1.0
First commit.
