Changelog
==========

#### 1.0.0 - July 30, 2022

Initial plugin release.
