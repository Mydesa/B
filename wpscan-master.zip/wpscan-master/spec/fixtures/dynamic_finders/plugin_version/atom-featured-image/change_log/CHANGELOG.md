## Changelog ##

### 1.0 ###
* Initial Release

### 1.0.1 ###
* Link to settings page now available in list of installed plugins
