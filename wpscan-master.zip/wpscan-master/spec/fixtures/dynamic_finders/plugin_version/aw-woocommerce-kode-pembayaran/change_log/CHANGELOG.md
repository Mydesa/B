## Version 1.1.3
- FIX - Update PHP License
- FIX - Compatible to WordPress 4.5.3

## Version 1.1.2
- NEW - Range number
- TWEAK - add aw tools
- TWEAK - code php

## Version 1.1.1
- Penambahan Metode Biaya Pengurangan

## Version 1.1.0
- Penambahan fitur nomor hp
- Penambahan fitur kode pos
- Penambahan fitur cookies untuk kode unik
- Penghapusan nomor awal dan nomor akhir
- Perbaikan bug

## Version 1.0.1
- Perbaikan bug update options

## Version 1.0.0 ( 30 November 2014 )
- Product Launching