# Changelog

## 1.0.1

- Updated readme

## 1.0.0

- Initial