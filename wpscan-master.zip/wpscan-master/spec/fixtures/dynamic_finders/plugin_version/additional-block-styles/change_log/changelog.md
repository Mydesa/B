# Additional Block Styles Changelog

## 1.0.0, 20220330

- Initial release.
