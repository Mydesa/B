## [1.0.1] - 2021-09-29

- Fix fa-icon block type

## [1.0.0] - 2021-09-29

- First release
