Changelog
=========

#### 1.0.1 - May 10, 2019

**Fixed**
- AffiliateWP integration subscribing the wrong user if affiliate ID differs from user ID.
- Broken url

**Improvements**
- Test by latest wordpress 5.2

#### 1.0.0 - September 21, 2018

**Changes**

- Change module name from AvangEmail to AvangPress
- Change logo

**Additions**

- Fix bug on detect connection
- Fix bug saved list to database.


#### 0.0.1 - August 8, 2018

**Improvements**

- Init project based on AvangPress for wordpress plugin

**Additions**

- Add AvangPress php api to project.
