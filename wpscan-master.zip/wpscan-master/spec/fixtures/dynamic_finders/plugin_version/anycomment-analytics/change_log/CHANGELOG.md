# Changelog

## 0.2 - 30.03.2019

- Added option to control where generic report would be sent and to define interval of such email
- Added generic report with multiple summary information send directly to email 

## 0.1 – 11.02.2019

First release.